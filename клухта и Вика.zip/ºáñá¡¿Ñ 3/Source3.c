#include <stdlib.h>
#include <locale.h>
void main()
{
	puts("   __    __  __    __   __ ");
	puts("/|   |  |  | __|  |  | |__|");
	puts(" |   |. |__| __|. |__| |__|");
}