#include <stdio.h>
void main()
{
	puts("                    _______              ");
	puts("                   |       \\             ");
	puts("                   |        \\            ");
	puts("                   |         |           ");
	puts("                   |        /            ");
	puts("                   |_______/             ");
	puts("                   |                     ");
	puts("                   |                     ");
	puts("          _________|__________           ");
	puts("          \\                  /           ");
	puts("           \\                /            ");
	puts("            ----------------             ");
	return 0;
}